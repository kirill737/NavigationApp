import UIKit

class MyMenuViewController: UIViewController {
    private let startTextField = UITextField()
    private let endTextField = UITextField()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }

    func setupView() {
        view.backgroundColor = .darkGray
        view.layer.cornerRadius = 16
        view.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        startTextField.placeholder = "Start"
        endTextField.placeholder = "End"
        
        startTextField.borderStyle = .roundedRect
        endTextField.borderStyle = .roundedRect

        startTextField.backgroundColor = .white
        endTextField.backgroundColor = .white

        startTextField.addTarget(self, action: #selector(textFieldTapped(_:)), for: .editingDidBegin)
        endTextField.addTarget(self, action: #selector(textFieldTapped(_:)), for: .editingDidBegin)

        let stackView = UIStackView(arrangedSubviews: [startTextField, endTextField])
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stackView)

        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    @objc private func textFieldTapped(_ textField: UITextField) {
        if let sheetPresentationController = presentationController as? UISheetPresentationController {
            sheetPresentationController.animateChanges {
                sheetPresentationController.selectedDetentIdentifier = .large
            }
        }
    }
}
