//
//  PathNodeModel.swift
//  KNIR
//
//  Created by kirill on 15.05.2024.
//

import Foundation

class PathNode {
    var name: String
    var floor: Int
    var timeToReach: Int
    var prev: PathNode?
    var visited: Bool
    var neighbors: [(PathNode, Int)]
    
    init(name: String, floor: Int) {
        self.name = name
        self.floor = floor
        self.timeToReach = Int.max
        self.prev = nil
        self.visited = false
        self.neighbors = []
    }
    
    func resetNode() {
        self.timeToReach = Int.max
        self.prev = nil
        self.visited = false
    }
    
    func addNeibs(_ neibs: [(PathNode, Int)]) {
        self.neighbors.append(contentsOf: neibs)
    }
    func addNeib(_ neib: PathNode, _ time: Int) {
        self.neighbors.append((neib, time))
    }
}
