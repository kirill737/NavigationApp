//
//  ViewController.swift
//  KNIR
//
//  Created by kirill on 14.05.2024.
//

import UIKit
import SwiftUI

class ViewController: UIViewController, UISheetPresentationControllerDelegate {
//    @IBOutlet weak var startTextField: UITextField!
//    @IBOutlet weak var endTextField: UITextField!
    let startTextField = UITextField()
    let endTextField =  UITextField()
    @IBOutlet weak var pathTextView: UITextView!
    @IBOutlet weak var findPathButton: UIButton!
//    @IBOutlet weak var floorStepper: UIStepper!
    @IBOutlet weak var floorLabel: UILabel!
    @IBOutlet weak var floorMenuTableVIew: UITableView!
    
    //Select Campus logic
    @IBOutlet weak var selectCampusButton: UIButton!
    var validCampuses = ["Корпус А", "Корпус Б", "Корпус Г"]
    private var selectedCampus = ""
//    @State private var isSheetPresented = false

    // To do: при выходе с поля если имя невалидное то отчистить его
    var startName: String = ""
    var endName: String = ""
    var map: Map = Map(6)
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presentMyMenu()
        mainView()
        
        
        
//        selectCampusButton.translatesAutoresizingMaskIntoConstraints = false
//        NSLayoutConstraint.activate([
//            selectCampusButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            selectCampusButton.centerYAnchor.constraint(equalTo: view.centerYAnchor)
//        ])
    }
    
    func presentMyMenu() {
        let myMenuVC = MyMenuViewController()
        myMenuVC.modalPresentationStyle = .pageSheet

        if let sheet = myMenuVC.sheetPresentationController {
            sheet.detents = [.medium(), .large()]
            sheet.prefersGrabberVisible = true
            sheet.prefersEdgeAttachedInCompactHeight = true
            sheet.widthFollowsPreferredContentSizeWhenEdgeAttached = true
        }

        present(myMenuVC, animated: true, completion: nil)
    }
    private func mainView() {
        selectCampusButton.setTitle("Корпус А", for: .normal)
        selectCampusButton.tintColor = UIColor.blue
        selectCampusButton.addTarget(self, action: #selector(openSearch), for: .touchUpInside)
        view.addSubview(selectCampusButton)
        
        map.initializeGraph()
        print(map.currentFloor)
        startName = startTextField.text!;
        endName = endTextField.text!;
        validateTextFields()
        findPathButton.addTarget(self, action: #selector(findPathButtonAction), for: .touchUpInside)
        startTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        endTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    
        floorMenuTableVIew.delegate = self
        floorMenuTableVIew.dataSource = self
        
        floorMenuTableVIew.register(UITableViewCell.self, forCellReuseIdentifier: "FloorCell")
        
        floorMenuTableVIew.separatorStyle = .none
        floorMenuTableVIew.backgroundColor = UIColor.clear
        floorMenuTableVIew.isScrollEnabled = (map.floorsAmount > 6)
    }
    
    @objc func openSearch() {
        var searchSwiftUIView = SearchSwiftUIView(searchSelectedCampus: selectedCampus, validCampuses: validCampuses)

        searchSwiftUIView.searchSelectedCampus = selectedCampus
        searchSwiftUIView.onSelectCampus = { [weak self] selectedCampus in // Явное захватывание self
            self?.selectedCampus = selectedCampus
            print(self!.selectedCampus)
            self?.selectCampusButton.setTitle(self?.selectedCampus, for: .normal)
            self?.dismiss(animated: true, completion: nil)
        }

        let controller = UIHostingController(rootView: searchSwiftUIView)
        let sheetController = controller.sheetPresentationController
        sheetController?.detents = [.medium(), .large()]
        sheetController?.preferredCornerRadius = 16
        sheetController?.prefersGrabberVisible = true
        sheetController?.delegate = self
        present(controller, animated: true)
    }


    
    func selectRow(floor: Int) {
        let indexPath = IndexPath(row: floor - 1, section: 0)
        floorMenuTableVIew.selectRow(at: indexPath, animated: true, scrollPosition: .none)
        floorMenuTableVIew.delegate?.tableView?(floorMenuTableVIew, didSelectRowAt: indexPath)
    }

    
}

extension ViewController: UIAdaptivePresentationControllerDelegate {
    func presentationControllerShouldDismiss(_ presentationController: UIPresentationController) -> Bool {
        true
    }
}

// Text fields
extension ViewController {
    @IBAction func startTextFieldEndEditing(_ sender: UITextField) {
        print("завершил редактирование текстового поля start")
        if (endTextField.text == sender.text) {endTextField.text = nil}
    }

    @IBAction func endTextFieldEndEditing(_ sender: UITextField) {
        print("завершил редактирование текстового поля end")
        if (startTextField.text == sender.text) {startTextField.text = nil}
    }
    @objc func textFieldDidChange(_ textField: UITextField) {
        validateTextFields()
    }
    func isValidPoint(_ text:  String?) -> Bool {
        if text == nil {
            return false }
        if map.wholeGraph.nodeMap[text!] != nil {
            return true
        }
        return false
        
    }
    func validateTextFields() {
        startName = startTextField.text!
        endName = endTextField.text!
        if isValidPoint(startName), isValidPoint(endName) {
            findPathButton!.isEnabled = true
        } else { findPathButton.isEnabled = false }
    }
}

// BuildPath button
extension ViewController {
    @IBAction func findPathButtonAction(_ sender: Any) {
        print("\t\tButton pushed")
        map.currentFloor = map.wholeGraph.nodeMap[startName]!.floor
        selectRow(floor: map.currentFloor)
        pathTextView.text = nil
        startName = startTextField.text!;
        endName = endTextField.text!;
        print("inited names")
        map.findPath(startName, endName)
        print("found path")
        print("On floor \(map.currentFloor)")
        showPath(path: map.leveledPath[map.currentFloor]!, floor: map.currentFloor)
        print("end")
    }
    
    func showPath(path: [PathNode], floor: Int) {
        print("\t\tStart show path")
//        pathTextView.text = ""
//        let pathCopy: [PathNode] = map.leveledPath[floor]!
        let pathCopy: [PathNode] = path
        var pathText: String = "The shortest path \(startName) -> \(endName):\n"
        if !pathCopy.isEmpty {
//            pathTextView.text =
            
            for node in pathCopy {
//                if node.floor == prevFloor + 1 {
//                    pathText += "\nNeed to go up\n(\(node.timeToReach)) \(node.name)"
//                } else if node.floor == prevFloor - 1 {
//                    pathText += "\nNeed to go down\n(\(node.timeToReach)) \(node.name)"
//                } else {
                    pathText += "(\(node.timeToReach)) \(node.name)"
//                }
                if node.name != endName {
                    pathText += " -> "
                }
            }
            pathText += "\nTotal time: \(pathCopy.last!.timeToReach)"
        } else {
            pathText += "\nPath not found"
        }
        pathTextView.text = pathText
    }
}


// Floor Menu
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return map.floorsAmount
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FloorCell", for: indexPath)
        cell.textLabel?.text = "\(indexPath.row + 1)"
        cell.indentationWidth = 1
        cell.textLabel?.textAlignment = .center
        cell.textLabel?.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        cell.textLabel?.textColor = .black

        if map.currentFloor == indexPath.row + 1 {
            cell.contentView.backgroundColor = .blue
            cell.textLabel?.textColor = .white
            cell.layer.cornerRadius = 3
            cell.clipsToBounds = true
        } else {
            cell.contentView.backgroundColor = .white
            cell.textLabel?.textColor = .black
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        map.currentFloor = indexPath.row + 1
        tableView.reloadData()
        floorLabel.text = "Этаж \(map.currentFloor)"
        if map.isWithPath { showPath(path: map.leveledPath[map.currentFloor]!, floor: map.currentFloor) }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        let totalCellsHeight = tableView.bounds.height
//        let totalCellsCount = tableView.numberOfRows(inSection: 0)
//        return totalCellsHeight / CGFloat(totalCellsCount)
        return 35.0
    }
}




