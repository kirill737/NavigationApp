//
//  GraphModel.swift
//  KNIR
//
//  Created by kirill on 15.05.2024.
//

import Foundation

class Graph {
    var path: [PathNode]
    var nodeMap: [String: PathNode]
    
    init() {
        self.nodeMap = [:]
        path = []
    }
    
    public func add(_ name: String, _ floor: Int) {
        self.nodeMap[name] = PathNode(name: name, floor: floor)
    }
    public func connectNodes(_ src: String, _ dst: String, _ time: Int, _ isBothSides: Bool = true) {
        // guard let _ = graph.nodeMap[src] {
        //     throw GraphError.SrcNodeNotFound
        // }
        // guard let _ = graph.nodeMap[dst] {
        //     throw GraphError.DstNodeNotFound
        // }
        self.nodeMap[src]!.addNeib(self.nodeMap[dst]!, time)
        if isBothSides { self.nodeMap[dst]!.addNeib(self.nodeMap[src]!, time) }
    }
    public func connectManyNodes(_ src: String, _ dstsWithTime: [(String, Int)]) {
        for pair in dstsWithTime {
            self.connectNodes(src, pair.0, pair.1)
        }
    }
    
    
}

//enum GraphError: Error {
//    case SrcNodeNotFound
//    case DstNodeNotFound
//}




// ViewController.swift

