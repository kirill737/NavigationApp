//
//  MapModel.swift
//  KNIR
//
//  Created by elena on 17.05.2024.
//

import Foundation

class Map {
    var currentFloor: Int {
        didSet {
            updateAllWithFloor()
        }
    }
    var floorsAmount: Int
    var isWithPath: Bool = false
    var wholeGraph: Graph
    var path: [PathNode] = []
    var leveledPath: [Int : [PathNode]]  = [:]
    var availablePoints: [String] = []
    
    init(_ floorsAmount: Int) {
        currentFloor = 1
        self.floorsAmount = floorsAmount
//        isWithPath = false
        wholeGraph = Graph()
//        path = []
        for i in 1...floorsAmount {
            leveledPath[i] = []
        }
    }
    func updateAllWithFloor() {
        
    }
    func resetMap() {
        for (_, pathNode) in wholeGraph.nodeMap {
            pathNode.resetNode()
        }
        isWithPath = false
        path.removeAll()
        for i in 1...floorsAmount  {
            leveledPath[i]?.removeAll()
        }
    }
    public func findPath(_ startName: String, _ endName: String)
    {
        print("\t\tStart finding a path from \(startName) to \(endName)")
        resetMap()
        guard let start = wholeGraph.nodeMap[startName], let end = wholeGraph.nodeMap[endName] else {
            fatalError("Departure node does not exist")
        }
//        print("from \(start.name) to \(end.name)")
        
    
        start.timeToReach = 0
        start.prev = nil
        
        var pq = [(Int, PathNode)]()
        pq.append((start.timeToReach, start))
        
        while !pq.isEmpty {
            pq.sort { $0.0 < $1.0 }
            let current = pq.removeFirst().1
//            print("Current name \(current.name)")
//            print("\n neibs")
//            for i in current.neighbors {
//                print(i.0.name, i.1)
//            }
            
            if current === end {
//                print("break cur = end")
                break
            }
            
            if !current.visited {
                current.visited = true
                for neib: (PathNode, Int) in current.neighbors {
                    let neighbor: PathNode = neib.0
                    let weight: Int = neib.1
                    if !neighbor.visited {
                        let newTime: Int = current.timeToReach + weight
                        if newTime < neighbor.timeToReach {
                            neighbor.timeToReach = newTime
                            neighbor.prev = current
                            pq.append((neighbor.timeToReach, neighbor))
                        }
                    }
                }
            }
        }
        
        var current: PathNode? = end
        while let curr = current {
            path.insert(curr, at: 0)
            leveledPath[curr.floor]?.insert(curr, at: 0)
            current = curr.prev
        }
        isWithPath = true
        
    }
    
    public func initializeGraph() {
        wholeGraph.add("A1", 1)
        wholeGraph.add("B1", 1)
        wholeGraph.add("C1", 1)
        wholeGraph.add("D1", 1)
        wholeGraph.add("E1", 1)
        wholeGraph.add("A2", 2)
        wholeGraph.add("B2", 2)
        wholeGraph.add("D2", 2)
        wholeGraph.add("E2", 2)
        
        wholeGraph.connectManyNodes("A1", [("B1", 2), ("C1", 4)])
        wholeGraph.connectNodes("A1", "A2", 5, false)
        wholeGraph.connectNodes("A2", "A1", 3, false)
        wholeGraph.connectManyNodes("B1", [("C1", 1), ("D1", 7)])
        wholeGraph.connectManyNodes("C1", [("D1", 3)])
        wholeGraph.connectManyNodes("D1", [("E1", 1)])
        wholeGraph.connectNodes("D1", "D2", 5, false)
        wholeGraph.connectNodes("D2", "D1", 3, false)
        wholeGraph.connectManyNodes("E1", [("D1", 1)])
        wholeGraph.connectManyNodes("A2", [("B2", 5), ("D2", 8)])
        wholeGraph.connectManyNodes("B2", [("D2", 4)])
        wholeGraph.connectManyNodes("D2", [("E2", 2)])
//        wholeGraph.connectManyNodes("E2", [("D2", 2)])
        for (name, _) in wholeGraph.nodeMap {
            self.availablePoints.append(name)
        }
        print(self.availablePoints)

    }
    
    
}
